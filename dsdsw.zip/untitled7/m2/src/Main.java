import java.util.ArrayList;

public class Main extends User {
    static ArrayList<User> registered =new ArrayList<>();
    static ArrayList<Application> regist =new ArrayList<>();

    public static void main(String[] args) {

   User user = new User();
    bid bid1 = new bid();
    user.createZayava(regist," aaa","это текст");

    bid1.add(registered, "vlad", "posdnakov", 122321, 1);
     System.out.println(registered.size());

  }
}
