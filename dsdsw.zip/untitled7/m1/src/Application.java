public class Application {
    private String text;
    private String name1;
    private int createid;

    public String getName(){
        return name1;
    }
    public void setName(String name){
        this.name1 = name;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
    public int getCreateid(){
        return createid;
    }
    public void setCreateid(int createid){
        this.createid = createid;
    }


}


