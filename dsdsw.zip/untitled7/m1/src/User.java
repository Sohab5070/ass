import java.util.ArrayList;

public class User
{
    private String name;
    private String surname;
    private int numpass;
    private int id;

    public void setId(int name) {
        this.id = id;
    }
    public  int getId() {
        return  id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getSurname() {
        return surname;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public int getNumpass(){
        return numpass;
    }
    public void setNumpass(int numpass){
        this.numpass= this.numpass;
    }
    public void createZayava (ArrayList<Application> regist, String name1, String text)
    {
        Application new_application = new Application();
        new_application.setName(name1);
        new_application.setText(text);
        new_application.setCreateid(this.id);
        regist.add( new_application );


    }
}
