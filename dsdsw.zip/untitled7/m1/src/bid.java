
import java.util.ArrayList;

public class bid
{


public void add(ArrayList registered, String name,String surname,int numpass , int id)
{

    User new_user= new User();
    new_user.setSurname(surname);
    new_user.setName(name);
    new_user.setNumpass(numpass);
    new_user.setId(id);
    registered.add(new_user);
}
    public void del(ArrayList<User> registered, String name,String surname, int numpass)
    {
        for (int i=0;i<registered.size();i++){

            if(registered.get(i).getName().equals(name) && registered.get(i).getSurname().equals(surname) && registered.get(i).getNumpass()==numpass)
            {
                registered.remove(i);
            }
        }
    }
}
